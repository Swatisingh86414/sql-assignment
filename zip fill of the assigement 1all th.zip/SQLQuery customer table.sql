Use salesman

CREATE TABLE Customer (
    SalesmanId INT,
    CustomerId INT,
    CustomerName VARCHAR(255),
    PurchaseAmount INT,
    );


	INSERT INTO Customer (SalesmanId, CustomerId, CustomerName, PurchaseAmount)
VALUES
    (101, 2345, 'Andrew', 550),
    (103, 1575, 'Lucky', 4500),
    (104, 2345, 'Andrew', 4000),
    (107, 3747, 'Remona', 2700),
    (110, 4004, 'Julia', 4545);

	select * from customer

 Update the c.salesmanid in the Customer table on cte 
UPDATE Customer
SET SalesmanId = CTE.c.salesmanid

FROM Customer

-- Verify the update
SELECT * FROM Customer;