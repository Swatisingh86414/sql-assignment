CREATE DATABASE salesman;

USE salesman;

CREATE TABLE Salesman (
    SalesmanId INT,
     Name VARCHAR(255),
    Commission DECIMAL(10, 2),
    City VARCHAR(255),
    Age INT
);

INSERT INTO Salesman (SalesmanId, Name, Commission, City, Age)
VALUES
    (101, 'Joe', 50, 'California', 17),
    (102, 'Simon', 75, 'Texas', 25),
    (103, 'Jessie', 105, 'Florida', 35),
    (104, 'Danny', 100, 'Texas', 22),
    (105, 'Lia', 65, 'New Jersey', 30);

--select

select * from salesman
select * from Customer where CustomerName like '%N' and >500;

--CONSTRAINTS--
--NOT NULL 

select * from salesman

alter table salesman alter column salesmanid int  not null

alter table salesman add constraint pri_key primary key(salesmanid)

-- Add Default constraint to City column in the Salesman table
ALTER TABLE Salesman
ADD CONSTRAINT DF_Salesman_City DEFAULT 'Unknown' FOR City;
select * from salesman

insert into salesman (SalesmanId,name,Commission,age)
values (106,'swati',20,28)

select * from salesman -- Pri Key

SELECT * FROM Customer
WHERE customerid in ( 102,103,104,105,106 )
ORDER BY SalesmanID


ALTER TABLE Customer

select * from customer 

delete from customer where SalesmanId not in (select SalesmanId from salesman)

select * from salesman

alter table customer add constraint  f_salesmanid foreign key (salesmanid) references Salesman(salesmanid);
select * from salesman  -- Pri Key

select * from customer  -- F Key



-- Alter the Customer table to add the NOT NULL constraint
ALTER TABLE Customer
ALTER COLUMN CustomerName VARCHAR(255) NOT NULL;

select * from Customer
select * from Orders
select * from Salesman

-- join

select   o.Orderdate,s.Name,a.customername,s.Commission,s.City from customer a inner join Orders o 
on a.salesmanId�=�o.salesmanId inner join salesman s on o.salesmanid =s.salesmanid
where a.PurchaseAmount  between 500 and 1500

---set operators

select a.salesmanId,a.customerId,a.customerName,a.purchaseAmount from customer a
  union 
  select b.salesmanId,b.customerId,b.customerName,b.purchaseAmount from customer b

select a.salesmanId,a.customerId,a.customerName,a.purchaseAmount from customer a
  union all
  select b.salesmanId,b.customerId,b.customerName,b.purchaseAmount from customer b

  
 ---right join--
 select * from Salesman s right join Orders o on s.SalesmanId =  o.SalesmanId
