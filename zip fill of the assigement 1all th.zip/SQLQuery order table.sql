USE salesman

CREATE TABLE Orders (OrderId int, CustomerId int, SalesmanId int, Orderdate Date, Amount money)


INSERT INTO Orders Values 
(5001,2345,101,'2021-07-01',550),
(5003,1234,105,'2022-02-15',1500)

select * from orders

INSERT INTO Orders 
(OrderId, CustomerId , SalesmanId , Orderdate , Amount )
Values 
(5005,1545,103,'2022-05-25',1000),
(5008,3747,107,'2023-08-05',2700),
(5010,1250,110,'2023-11-25',3000)
